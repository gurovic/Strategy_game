from .libgame import *

__doc__ = libgame.__doc__
if hasattr(libgame, "__all__"):
    __all__ = libgame.__all__